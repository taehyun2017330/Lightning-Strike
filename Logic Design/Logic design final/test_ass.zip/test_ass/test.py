Reg = [0 for _ in range(4)]
DMEM = [i for i in range(16)] + [256-i for i in range(16)] + [0 for _ in range(1000)]
IMEM = ["" for _ in range(100)]

def getInst(pc):
    return IMEM[pc]

def runInst(pc):
    inst = getInst(pc)
    str = inst.split() + [None,None,None,None,None]

    opcode = str[0]
    rs = int(str[1]) if (opcode!='j') else 0
    rt = int(str[2]) if (opcode!='j') else 0
    rd = int(str[3]) if (opcode!="j") else int(str[1])
    imm = int(str[3]) if (opcode!="j") else int(str[1])
    wd = 0

    if(opcode == "add"):
        Reg[rd] = (Reg[rs] + Reg[rt])%256
        wd = Reg[rd]
    elif(opcode == "lw"):
        Reg[rt] = (DMEM[(Reg[rs] + imm + 256)%256] + 256)%256
        wd = Reg[rt]
    elif(opcode == "sw"):
        DMEM[(Reg[rs] + imm + 256)%256] = Reg[rt]
        wd = Reg[rt]
    else:
        wd = 0
        pc += imm

    pc += 1
    return (pc, wd, inst)



fi = open("input.in", "r")
i = 0
while True:
    line = fi.readline()
    if not line: break
    IMEM[i] = line.strip()
    i = i+1
fi.close

buffer = ""
pc = 0
j = 0
for j in range(100) :
    if(i <= pc): break
    pc, wd, inst = runInst(pc)
    buffer += hex(wd)[2:] + '\t\t' + inst + "\t\t" + str(Reg[0]) + " " + str(Reg[1]) + " " + str(Reg[2]) + " " + str(Reg[3]) + "\n"


fo = open("run.out", "w")
fo.write(buffer)
fo.close()
