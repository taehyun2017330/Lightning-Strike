def bin(str1):
    if(str1 == None): return "00"

    if(str1 == '0'): return "00"
    if(str1 == '1'): return "01"
    if(str1 == '2' or str1 == '-2'): return "10"
    if(str1 == '3' or str1 == '-1'): return "11"

def binOpcode(str):
    opDict = {"add" : "00", "lw" : "01", "sw" : "10", "j" : "11"}
    return opDict[str] if str in opDict else "00"

def assamble(str):
    str = str.split() + [None,None,None,None,None]

    opcode = binOpcode(str[0])
    rs = bin(str[1] if (opcode!='11') else None)
    rt = bin(str[2] if (opcode!='11') else None)
    rd = bin(str[3] if (opcode!="11") else str[1])

    return opcode + rs + rt + rd # rd == imm


fi = open("input.in", "r")
buffer = ""
i = 0

while True:
    line = fi.readline()
    if not line: break
    buffer += "assign MemByte[" + str(i) + "] = {8'b" + assamble(line) + "};\n"
    i = i+1

fi.close()


fo = open("output.out", "w")
fo.write(buffer)
fo.close()
