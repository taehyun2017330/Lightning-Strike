/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/csehome/ktwin01/logic design/processor/DMEM.v";
static unsigned int ng1[] = {0U, 0U};
static int ng2[] = {0, 0};
static unsigned int ng3[] = {1U, 0U};
static int ng4[] = {1, 0};
static unsigned int ng5[] = {2U, 0U};
static int ng6[] = {2, 0};
static unsigned int ng7[] = {3U, 0U};
static int ng8[] = {3, 0};
static unsigned int ng9[] = {4U, 0U};
static int ng10[] = {4, 0};
static unsigned int ng11[] = {5U, 0U};
static int ng12[] = {5, 0};
static unsigned int ng13[] = {6U, 0U};
static int ng14[] = {6, 0};
static unsigned int ng15[] = {7U, 0U};
static int ng16[] = {7, 0};
static unsigned int ng17[] = {8U, 0U};
static int ng18[] = {8, 0};
static unsigned int ng19[] = {9U, 0U};
static int ng20[] = {9, 0};
static unsigned int ng21[] = {10U, 0U};
static int ng22[] = {10, 0};
static unsigned int ng23[] = {11U, 0U};
static int ng24[] = {11, 0};
static unsigned int ng25[] = {12U, 0U};
static int ng26[] = {12, 0};
static unsigned int ng27[] = {13U, 0U};
static int ng28[] = {13, 0};
static unsigned int ng29[] = {14U, 0U};
static int ng30[] = {14, 0};
static unsigned int ng31[] = {15U, 0U};
static int ng32[] = {15, 0};
static int ng33[] = {16, 0};
static unsigned int ng34[] = {255U, 0U};
static int ng35[] = {17, 0};
static unsigned int ng36[] = {254U, 0U};
static int ng37[] = {18, 0};
static unsigned int ng38[] = {253U, 0U};
static int ng39[] = {19, 0};
static unsigned int ng40[] = {252U, 0U};
static int ng41[] = {20, 0};
static unsigned int ng42[] = {251U, 0U};
static int ng43[] = {21, 0};
static unsigned int ng44[] = {250U, 0U};
static int ng45[] = {22, 0};
static unsigned int ng46[] = {249U, 0U};
static int ng47[] = {23, 0};
static unsigned int ng48[] = {248U, 0U};
static int ng49[] = {24, 0};
static unsigned int ng50[] = {247U, 0U};
static int ng51[] = {25, 0};
static unsigned int ng52[] = {246U, 0U};
static int ng53[] = {26, 0};
static unsigned int ng54[] = {245U, 0U};
static int ng55[] = {27, 0};
static unsigned int ng56[] = {244U, 0U};
static int ng57[] = {28, 0};
static unsigned int ng58[] = {243U, 0U};
static int ng59[] = {29, 0};
static unsigned int ng60[] = {242U, 0U};
static int ng61[] = {30, 0};
static unsigned int ng62[] = {241U, 0U};
static int ng63[] = {31, 0};



static int sp_reset(char *t1, char *t2)
{
    char t7[8];
    char t8[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    int t18;
    char *t19;
    unsigned int t20;
    int t21;
    int t22;
    unsigned int t23;
    unsigned int t24;
    int t25;
    int t26;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(32, ng0);

LAB5:    xsi_set_current_line(33, ng0);
    t5 = ((char*)((ng1)));
    t6 = (t1 + 2840);
    t9 = (t1 + 2840);
    t10 = (t9 + 72U);
    t11 = *((char **)t10);
    t12 = (t1 + 2840);
    t13 = (t12 + 64U);
    t14 = *((char **)t13);
    t15 = ((char*)((ng2)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t11, t14, 2, 1, t15, 32, 1);
    t16 = (t7 + 4);
    t17 = *((unsigned int *)t16);
    t18 = (!(t17));
    t19 = (t8 + 4);
    t20 = *((unsigned int *)t19);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB6;

LAB7:    xsi_set_current_line(34, ng0);
    t4 = ((char*)((ng3)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng4)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB8;

LAB9:    xsi_set_current_line(35, ng0);
    t4 = ((char*)((ng5)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng6)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(36, ng0);
    t4 = ((char*)((ng7)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng8)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(37, ng0);
    t4 = ((char*)((ng9)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng10)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB14;

LAB15:    xsi_set_current_line(38, ng0);
    t4 = ((char*)((ng11)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng12)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB16;

LAB17:    xsi_set_current_line(39, ng0);
    t4 = ((char*)((ng13)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng14)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB18;

LAB19:    xsi_set_current_line(40, ng0);
    t4 = ((char*)((ng15)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng16)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB20;

LAB21:    xsi_set_current_line(41, ng0);
    t4 = ((char*)((ng17)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng18)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB22;

LAB23:    xsi_set_current_line(42, ng0);
    t4 = ((char*)((ng19)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng20)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB24;

LAB25:    xsi_set_current_line(43, ng0);
    t4 = ((char*)((ng21)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng22)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB26;

LAB27:    xsi_set_current_line(44, ng0);
    t4 = ((char*)((ng23)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng24)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB28;

LAB29:    xsi_set_current_line(45, ng0);
    t4 = ((char*)((ng25)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng26)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB30;

LAB31:    xsi_set_current_line(46, ng0);
    t4 = ((char*)((ng27)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng28)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB32;

LAB33:    xsi_set_current_line(47, ng0);
    t4 = ((char*)((ng29)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng30)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB34;

LAB35:    xsi_set_current_line(48, ng0);
    t4 = ((char*)((ng31)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng32)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB36;

LAB37:    xsi_set_current_line(49, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng33)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB38;

LAB39:    xsi_set_current_line(50, ng0);
    t4 = ((char*)((ng34)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng35)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB40;

LAB41:    xsi_set_current_line(51, ng0);
    t4 = ((char*)((ng36)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng37)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB42;

LAB43:    xsi_set_current_line(52, ng0);
    t4 = ((char*)((ng38)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng39)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB44;

LAB45:    xsi_set_current_line(53, ng0);
    t4 = ((char*)((ng40)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng41)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB46;

LAB47:    xsi_set_current_line(54, ng0);
    t4 = ((char*)((ng42)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng43)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB48;

LAB49:    xsi_set_current_line(55, ng0);
    t4 = ((char*)((ng44)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng45)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB50;

LAB51:    xsi_set_current_line(56, ng0);
    t4 = ((char*)((ng46)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng47)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB52;

LAB53:    xsi_set_current_line(57, ng0);
    t4 = ((char*)((ng48)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng49)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB54;

LAB55:    xsi_set_current_line(58, ng0);
    t4 = ((char*)((ng50)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng51)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB56;

LAB57:    xsi_set_current_line(59, ng0);
    t4 = ((char*)((ng52)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng53)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB58;

LAB59:    xsi_set_current_line(60, ng0);
    t4 = ((char*)((ng54)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng55)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB60;

LAB61:    xsi_set_current_line(61, ng0);
    t4 = ((char*)((ng56)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng57)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB62;

LAB63:    xsi_set_current_line(62, ng0);
    t4 = ((char*)((ng58)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng59)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB64;

LAB65:    xsi_set_current_line(63, ng0);
    t4 = ((char*)((ng60)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng61)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB66;

LAB67:    xsi_set_current_line(64, ng0);
    t4 = ((char*)((ng62)));
    t5 = (t1 + 2840);
    t6 = (t1 + 2840);
    t9 = (t6 + 72U);
    t10 = *((char **)t9);
    t11 = (t1 + 2840);
    t12 = (t11 + 64U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng63)));
    xsi_vlog_generic_convert_array_indices(t7, t8, t10, t13, 2, 1, t14, 32, 1);
    t15 = (t7 + 4);
    t17 = *((unsigned int *)t15);
    t18 = (!(t17));
    t16 = (t8 + 4);
    t20 = *((unsigned int *)t16);
    t21 = (!(t20));
    t22 = (t18 && t21);
    if (t22 == 1)
        goto LAB68;

LAB69:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB6:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB7;

LAB8:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB9;

LAB10:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB11;

LAB12:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB13;

LAB14:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB15;

LAB16:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB17;

LAB18:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB19;

LAB20:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB21;

LAB22:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB23;

LAB24:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB25;

LAB26:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB27;

LAB28:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB29;

LAB30:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB31;

LAB32:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB33;

LAB34:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB35;

LAB36:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB37;

LAB38:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB39;

LAB40:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB41;

LAB42:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB43;

LAB44:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB45;

LAB46:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB47;

LAB48:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB49;

LAB50:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB51;

LAB52:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB53;

LAB54:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB55;

LAB56:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB57;

LAB58:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB59;

LAB60:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB61;

LAB62:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB63;

LAB64:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB65;

LAB66:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB67;

LAB68:    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t8);
    t25 = (t23 - t24);
    t26 = (t25 + 1);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, *((unsigned int *)t8), t26, 0LL);
    goto LAB69;

}

static void Cont_15_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t19[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;

LAB0:    t1 = (t0 + 3752U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1800U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t28 = *((unsigned int *)t4);
    t29 = (~(t28));
    t30 = *((unsigned int *)t12);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t26, 8);

LAB16:    t32 = (t0 + 4664);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    memset(t36, 0, 8);
    t37 = 255U;
    t38 = t37;
    t39 = (t3 + 4);
    t40 = *((unsigned int *)t3);
    t37 = (t37 & t40);
    t41 = *((unsigned int *)t39);
    t38 = (t38 & t41);
    t42 = (t36 + 4);
    t43 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t43 | t37);
    t44 = *((unsigned int *)t42);
    *((unsigned int *)t42) = (t44 | t38);
    xsi_driver_vfirst_trans(t32, 0, 7);
    t45 = (t0 + 4568);
    *((int *)t45) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = (t0 + 2840);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t20 = (t0 + 2840);
    t21 = (t20 + 72U);
    t22 = *((char **)t21);
    t23 = (t0 + 2840);
    t24 = (t23 + 64U);
    t25 = *((char **)t24);
    t26 = (t0 + 1480U);
    t27 = *((char **)t26);
    xsi_vlog_generic_get_array_select_value(t19, 32, t18, t22, t25, 2, 1, t27, 8, 2);
    goto LAB9;

LAB10:    t26 = ((char*)((ng2)));
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 32, t19, 32, t26, 32);
    goto LAB16;

LAB14:    memcpy(t3, t19, 8);
    goto LAB16;

}

static void Initial_17_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    t1 = (t0 + 4000U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);

LAB4:    xsi_set_current_line(18, ng0);
    t2 = (t0 + 3808);
    t3 = (t0 + 848);
    t4 = xsi_create_subprogram_invocation(t2, 0, t0, t3, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t3, t4);

LAB7:    t5 = (t0 + 3904);
    t6 = *((char **)t5);
    t7 = (t6 + 80U);
    t8 = *((char **)t7);
    t9 = (t8 + 272U);
    t10 = *((char **)t9);
    t11 = (t10 + 0U);
    t12 = *((char **)t11);
    t13 = ((int  (*)(char *, char *))t12)(t0, t6);

LAB9:    if (t13 != 0)
        goto LAB10;

LAB5:    t6 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t6);

LAB6:    t14 = (t0 + 3904);
    t15 = *((char **)t14);
    t14 = (t0 + 848);
    t16 = (t0 + 3808);
    t17 = 0;
    xsi_delete_subprogram_invocation(t14, t15, t0, t16, t17);

LAB1:    return;
LAB8:;
LAB10:    t5 = (t0 + 4000U);
    *((char **)t5) = &&LAB7;
    goto LAB1;

}

static void Always_21_2(char *t0)
{
    char t27[8];
    char t28[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t29;
    unsigned int t30;
    int t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    int t35;
    int t36;

LAB0:    t1 = (t0 + 4248U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(21, ng0);
    t2 = (t0 + 4584);
    *((int *)t2) = 1;
    t3 = (t0 + 4280);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(21, ng0);

LAB5:    xsi_set_current_line(22, ng0);
    t4 = (t0 + 2440U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 2120U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB16;

LAB17:
LAB18:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(22, ng0);

LAB9:    xsi_set_current_line(23, ng0);
    t11 = (t0 + 4056);
    t12 = (t0 + 848);
    t13 = xsi_create_subprogram_invocation(t11, 0, t0, t12, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t12, t13);

LAB12:    t14 = (t0 + 4152);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t22 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB14:    if (t22 != 0)
        goto LAB15;

LAB10:    t15 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t15);

LAB11:    t23 = (t0 + 4152);
    t24 = *((char **)t23);
    t23 = (t0 + 848);
    t25 = (t0 + 4056);
    t26 = 0;
    xsi_delete_subprogram_invocation(t23, t24, t0, t25, t26);
    goto LAB8;

LAB13:;
LAB15:    t14 = (t0 + 4248U);
    *((char **)t14) = &&LAB12;
    goto LAB1;

LAB16:    xsi_set_current_line(25, ng0);

LAB19:    xsi_set_current_line(26, ng0);
    t4 = (t0 + 1960U);
    t5 = *((char **)t4);
    t4 = (t0 + 2840);
    t11 = (t0 + 2840);
    t12 = (t11 + 72U);
    t13 = *((char **)t12);
    t14 = (t0 + 2840);
    t15 = (t14 + 64U);
    t16 = *((char **)t15);
    t17 = (t0 + 1480U);
    t18 = *((char **)t17);
    xsi_vlog_generic_convert_array_indices(t27, t28, t13, t16, 2, 1, t18, 8, 2);
    t17 = (t27 + 4);
    t29 = *((unsigned int *)t17);
    t22 = (!(t29));
    t19 = (t28 + 4);
    t30 = *((unsigned int *)t19);
    t31 = (!(t30));
    t32 = (t22 && t31);
    if (t32 == 1)
        goto LAB20;

LAB21:    goto LAB18;

LAB20:    t33 = *((unsigned int *)t27);
    t34 = *((unsigned int *)t28);
    t35 = (t33 - t34);
    t36 = (t35 + 1);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, *((unsigned int *)t28), t36, 0LL);
    goto LAB21;

}


extern void work_m_15299347501089796867_1714798787_init()
{
	static char *pe[] = {(void *)Cont_15_0,(void *)Initial_17_1,(void *)Always_21_2};
	static char *se[] = {(void *)sp_reset};
	xsi_register_didat("work_m_15299347501089796867_1714798787", "isim/PROC_test_isim_beh.exe.sim/work/m_15299347501089796867_1714798787.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
