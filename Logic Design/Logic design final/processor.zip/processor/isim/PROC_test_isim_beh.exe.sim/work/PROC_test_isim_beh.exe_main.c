/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_14141233628806692927_2983911711_init();
    work_m_15934971742023747898_2058220583_init();
    work_m_15544111250859746840_0293410659_init();
    work_m_15299347501089796867_1714798787_init();
    work_m_11727819791255153486_2082554893_init();
    work_m_13643684901378071420_3009618379_init();
    work_m_08679525628557660925_2489260062_init();
    work_m_12410898449992873669_2969929678_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_12410898449992873669_2969929678");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
