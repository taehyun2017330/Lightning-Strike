#include <linux/debugfs.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <asm/pgtable.h>

MODULE_LICENSE("GPL");

static struct dentry *dir, *output;
static struct task_struct *task;

struct packet
{
        pid_t pid;
        unsigned long virtualA;
        unsigned long physicalA;
};

static ssize_t read_output(struct file *fp,
                           char __user *user_buffer,
                           size_t length,
                           loff_t *position)
{
        struct packet pckt;
        pgd_t *pgd; // page global directory
        pud_t *pud; // page upper directory
        pmd_t *pmd; // page middle directory
        pte_t *pte; // page table entry / page table itself

        // Safely copy the input data from user space using copy_from_user()
        if (copy_from_user(&pckt, user_buffer, sizeof(struct packet)))
        {
                return -EFAULT;
        }

        task = pid_task(find_get_pid(pckt.pid), PIDTYPE_PID); // get task_struct
        if (!task)
        {
                return -ESRCH; // Return an error if the process was not found
        }

        pgd = pgd_offset(task->mm, pckt.virtualA);                       // get pgd from task -> mm
        pud = pud_offset(p4d_offset(pgd, pckt.virtualA), pckt.virtualA); // get pud from p4d
        pmd = pmd_offset(pud, pckt.virtualA);                            // get pmd from pud
        pte = pte_offset_kernel(pmd, pckt.virtualA);                     // get pte from pmd

        if (pte_present(*pte))
        {
                unsigned long pfn = pte_pfn(*pte);
                unsigned long offset = pckt.virtualA & ~PAGE_MASK;
                pckt.physicalA = (pfn << PAGE_SHIFT) | offset;
        }
        else
        {
                return -EFAULT; // the page isn't present in physical memory
        }

        // Safely copy the output data back to user space
        if (copy_to_user(user_buffer, &pckt, sizeof(struct packet)))
        {
                return -EFAULT;
        }

        return length;
}

static const struct file_operations dbfs_fops = {
    // Mapping file operations with your functions
    .read = read_output,

};

static int __init dbfs_module_init(void)
{
        // Implement init module

        dir = debugfs_create_dir("paddr", NULL);

        if (!dir)
        {
                printk("Cannot create paddr dir\n");
                return -1;
        }

        // Fill in the arguments below
        output = debugfs_create_file("output", S_IWUSR, dir, NULL, &dbfs_fops);

        printk("dbfs_paddr module initialize done\n");

        return 0;
}

static void __exit dbfs_module_exit(void)
{
        // Implement exit module
        debugfs_remove_recursive(dir);
        printk("dbfs_paddr module exit\n");
}

module_init(dbfs_module_init);
module_exit(dbfs_module_exit);
