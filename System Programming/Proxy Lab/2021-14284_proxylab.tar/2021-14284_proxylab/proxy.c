#include <stdio.h>
#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

#define CACHECOUNT 150
#define TOTAL 8192
#define HEADERCOUNT 50
#define empty "\r\n"

typedef struct target
{
    char httpslisten[TOTAL];
    char httpstype[TOTAL];
    char address[TOTAL];
    char content[TOTAL];
    char socket[15];
} target;

char *address[CACHECOUNT];
char *content_type[CACHECOUNT];
char *data[CACHECOUNT];
long size[CACHECOUNT];
long cache_lru[CACHECOUNT];
long lru = 1, cachecount = 0, header_cs = 0;
pthread_mutex_t mutex;

void url_convert(char *URL, target *targetServer)
{
    char *addresscontainer = strstr(URL, "//");

    // Obtain httpstype name
    addresscontainer = (addresscontainer != NULL) ? (addresscontainer + 2) : URL;

    char *socket = strstr(addresscontainer, ":");
    char *package = strstr(addresscontainer, "/");

    // Set content
    if (package == NULL)
    {
        strncpy(targetServer->content, "/", 2);
        package = addresscontainer + strlen(addresscontainer);
    }
    else
    {
        strncpy(targetServer->content, package, TOTAL);
    }

    // Set socket
    if (socket == NULL)
    {
        strncpy(targetServer->socket, "80", 3);
        socket = package;
    }
    else
    {
        strncpy(targetServer->socket, socket + 1, package - (socket + 1));
    }

    // Set address
    strncpy(targetServer->address, addresscontainer, socket - addresscontainer);
}
void connecttoServer(int clientfd, int serverfd,
                     target *targetServer, char header_names[HEADERCOUNT][TOTAL], char header_values[HEADERCOUNT][TOTAL], int header_num)
{

    // Buffer to hold our message
    char buff[3 * TOTAL + 5];

    // Write the first line
    int buff_len = snprintf(buff, TOTAL, "%s %s %s\r\n",
                            targetServer->httpslisten,
                            targetServer->content,
                            targetServer->httpstype);

    Rio_writen(serverfd, buff, buff_len);

    // Write http headers
    for (int i = 0; i < header_num; i++)
    {
        buff_len = snprintf(buff, sizeof(buff), "%s: %s\r\n",
                            header_names[i],
                            header_values[i]);

        Rio_writen(serverfd, buff, buff_len);
    }

    // End of headers
    Rio_writen(serverfd, empty, 2);
}

void readAndSendBody(rio_t *serverRio, int clientfd, const char *end_Address, int headerc_size, char *headerc_value)
{
    char buff[2 * TOTAL + 5];
    int size = 0;
    if (headerc_size == -1 || headerc_size > MAX_OBJECT_SIZE || headerc_value == NULL)
    {
        // Directly send
        while ((size = Rio_readnb(serverRio, buff, TOTAL)))
        {
            Rio_writen(clientfd, buff, size);
        }
    }
    else
    {
        /* Get the body of client data */
        char *data = malloc(headerc_size + 1);
        size = Rio_readnb(serverRio, data, headerc_size + 1);

        int actualStoreSize = ((size > headerc_size) ? headerc_size : size);

        /* Add the data to Cache */
        pthread_mutex_lock(&mutex);
        cache_write(data, actualStoreSize, end_Address, headerc_value);
        pthread_mutex_unlock(&mutex);

        /* Send data to client */
        Rio_writen(clientfd, data, actualStoreSize);

        /* Remember to free memory */
        free(data);
    }
}

void Header_insert(char header_names[HEADERCOUNT][TOTAL], char header_values[HEADERCOUNT][TOTAL], int *header_num, const char *name, const char *value)
{
    // Look for an existing header with the same name
    for (int i = 0; i < *header_num; i++)
    {
        if (!strcmp(name, header_names[i]))
        {
            // If found, don't add a new header and return immediately
            return;
        }
    }

    // If no matching header was found, add a new one
    strncpy(header_names[*header_num], name, TOTAL);
    strncpy(header_values[*header_num], value, TOTAL);
    // Increment the header count
    (*header_num)++;
}

void readAndSendHeaders(rio_t *serverRio, char header_names[HEADERCOUNT][TOTAL], char header_values[HEADERCOUNT][TOTAL], int clientfd, int *headerc_size, char **headerc_value, char *buff)
{
    int header_num = header_read(serverRio, header_names, header_values);
    for (int i = 0; i < header_num; i++)
    {
        if (!strcmp("Content-length", header_names[i]))
        {
            sscanf(header_values[i], "%d", headerc_size);
        }
        else if (!strcmp("Content-type", header_names[i]))
        {
            *headerc_value = header_values[i];
        }
        Rio_writen(clientfd, buff, strlen(buff));
    }
    Rio_writen(clientfd, empty, 2);
}

int header_read(rio_t *rp, char header_names[HEADERCOUNT][TOTAL], char header_values[HEADERCOUNT][TOTAL])
{
    char buff[TOTAL];
    int headers_readcount = 0;

    // Read the first line of header
    Rio_readlineb(rp, buff, TOTAL);

    // Loop until a line with only empty is encountered
    while (strcmp(buff, empty))
    {
        // Parse header line into name and value
        sscanf(buff, "%[^:]:%s\r\n", header_names[headers_readcount], header_values[headers_readcount]);

        // Increment the headers_readcount
        headers_readcount++;

        // Read the next line
        Rio_readlineb(rp, buff, TOTAL);
    }

    // Return the count of headers read
    return headers_readcount;
}

void cache_write(const char *targetData, const long dataSize, const char *targetAddress, const char *targetContent_type)
{
    long selectedCacheIndex = cachecount;

    while (header_cs + dataSize > MAX_CACHE_SIZE || cachecount >= CACHECOUNT)
    {
        long leastRecentUsage = (long)-1;
        long i = 0;

        while (i < cachecount)
        {

            if (cache_lru[i] < leastRecentUsage && size[i] > 0)
            {
                selectedCacheIndex = i;
                leastRecentUsage = cache_lru[i];
            }
            i++;
        }

        cachecount = cachecount - 1;

        free(data[selectedCacheIndex]);

        address[selectedCacheIndex][0] = 0;
        size[selectedCacheIndex] = 0;
    }

    // Allocate memory
    data[selectedCacheIndex] = malloc(dataSize);
    if (data[selectedCacheIndex] == NULL)
    {
        return;
    }

    // Add new data to the cache
    strncpy(content_type[selectedCacheIndex], targetContent_type, TOTAL);
    strncpy(address[selectedCacheIndex], targetAddress, TOTAL);
    memcpy(data[selectedCacheIndex], targetData, dataSize);
    size[selectedCacheIndex] = dataSize;
    cache_lru[selectedCacheIndex] = lru;

    // Update cache parameters
    header_cs += dataSize;
    lru = lru + 1;
    cachecount = cachecount + 1;
}

int cache_read(const char *targetAddress)
{
    int index = 0;
    while (index < cachecount)
    {
        if (!strcmp(address[index], targetAddress))
        {
            cache_lru[index] = ++lru;
            return index;
        }
        index = index + 1;
    }
    return -1;
}

void readAndSendFirstLine(rio_t *serverRio, int clientfd, char *buff)
{
    Rio_readlineb(serverRio, buff, TOTAL);
    Rio_writen(clientfd, buff, strlen(buff));
}

void datacontext(int clientfd, int serverfd, const char *end_Address)
{
    rio_t serverRio;
    Rio_readinitb(&serverRio, serverfd);

    char buff[2 * TOTAL + 5];
    int headerc_size = -1;
    char header_names[HEADERCOUNT][TOTAL], header_values[HEADERCOUNT][TOTAL];
    char *content_type = NULL;

    // Read and send the first line
    readAndSendFirstLine(&serverRio, clientfd, buff);

    // Read and send headers
    readAndSendHeaders(&serverRio, header_names, header_values, clientfd, &headerc_size, &content_type, buff);

    // Read and send body
    readAndSendBody(&serverRio, clientfd, end_Address, headerc_size, content_type);
}

void *concurrency(void *thread)
{
    int clientfd = (int)(long)thread;
    char buff[TOTAL], URL[TOTAL], cache_content_type[TOTAL];
    char header_names[HEADERCOUNT][TOTAL], header_values[HEADERCOUNT][TOTAL];
    target targetServer;
    rio_t clientRio;
    int serverfd;
    char *cacheData = NULL;
    int cacheSize;

    // Initialize clientRio and read the first line of the request
    Rio_readinitb(&clientRio, clientfd);
    if (!Rio_readlineb(&clientRio, buff, TOTAL))
        return NULL;
    sscanf(buff, "%s %s %s", targetServer.httpslisten, URL, targetServer.httpstype);

    // Try to find the requested content in cache
    pthread_mutex_lock(&mutex);
    int cacheIndex = cache_read(URL);

    if (cacheIndex != -1) // If cache hit, prepare to send data from cache
    {
        cacheSize = size[cacheIndex];
        cacheData = malloc(cacheSize);
        memcpy(cacheData, data[cacheIndex], cacheSize);
        strncpy(cache_content_type, content_type[cacheIndex], TOTAL);
    }
    pthread_mutex_unlock(&mutex);

    if (cacheData) // If data was found in cache
    {
        sendResponseFromCache(clientfd, cacheData, cacheSize, cache_content_type);
        free(cacheData);
    }
    else // Data not found in cache, retrieve from server
    {
        int header_num = header_read(&clientRio, header_names, header_values); // Read the remaining headers
        url_convert(URL, &targetServer);
        Header_insert(header_names, header_values, &header_num, "User-Agent", user_agent_hdr);
        Header_insert(header_names, header_values, &header_num, "Host", targetServer.address);
        Header_insert(header_names, header_values, &header_num, "Connection", "close");
        Header_insert(header_names, header_values, &header_num, "Proxy-Connection", "close");
        serverfd = Open_clientfd(targetServer.address, targetServer.socket);

        // Send request to remote server and forward the response to client
        connecttoServer(clientfd, serverfd, &targetServer, header_names, header_values, header_num);
        datacontext(clientfd, serverfd, URL);
    }

    // Clean up
    close(serverfd);
    close(clientfd);

    return;
}

void init()
{
    for (int i = 0; i < CACHECOUNT; ++i)
    {
        if (data[i])
        {
            free(data[i]);
            data[i] = NULL;
        }

        size[i] = 0;
        cache_lru[i] = CACHECOUNT - i;
    }
}

void sendResponseFromCache(int clientfd, char *cacheData, int cacheSize, char *cache_content_type)
{
    char buff[TOTAL];

    // Format http header
    int len = snprintf(buff, TOTAL,
                       "HTTP/1.0 200 OK\r\n"
                       "Server: Tiny Proxy Server\r\n"
                       "Content-type: %s\r\n" empty,
                       cache_content_type);

    // Write HTTP header to client
    Rio_writen(clientfd, buff, len);

    // Send main content to the client
    Rio_writen(clientfd, cacheData, cacheSize);
}

int main(int argc, char *argv[])
{

    for (int i = 0; i < CACHECOUNT; i++)
    {
        address[i] = malloc(TOTAL * sizeof(char));
        content_type[i] = malloc(TOTAL * sizeof(char));
        data[i] = NULL;
    }
    pthread_attr_t attr_t;
    pthread_attr_init(&attr_t);
    pthread_attr_setdetachstate(&attr_t, PTHREAD_CREATE_DETACHED);
    struct sockaddr_storage clientaddr;
    socklen_t clientlen;
    char hostname[TOTAL], socket[TOTAL];
    int listenfd = Open_listenfd(argv[1]);

    init();

    for (;;)
    {
        clientlen = sizeof(clientaddr);
        int connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        Getnameinfo((SA *)&clientaddr, clientlen, hostname, TOTAL, socket, TOTAL, 0);
        pthread_t thread;
        pthread_create(&thread, &attr_t, concurrency, (void *)(long)connfd);
    }

    return 1;
}
